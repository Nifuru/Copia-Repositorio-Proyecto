import React from 'react';
import NavbarPage from '../../components/NavbarPage';


function CmiClientes() {
  return (
    <div>
      <NavbarPage/> 
      {
      <div className="hero">
        
     </div>
      }
    </div>
  );
}

export default CmiClientes;