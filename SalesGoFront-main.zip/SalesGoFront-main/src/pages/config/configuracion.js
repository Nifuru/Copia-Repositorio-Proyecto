import React from 'react';
import NavbarPage from '../../components/NavbarPage';
function Configuracion() {
    return (
      <div>
        <NavbarPage/> 
        {
        <div >
          ola
       </div>
        }
      </div>
    );
  }
  
  export default Configuracion;